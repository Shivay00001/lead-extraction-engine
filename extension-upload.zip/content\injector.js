/**
 * Lead Extraction Engine - Content Injector
 * Detects current platform and injects appropriate extractor
 */

const PLATFORMS = [
    // PRIMARY
    { name: 'google_maps', pattern: /google\..*\/maps/ },
    { name: 'google_search', pattern: /google\..*\/search/ },
    { name: 'justdial', pattern: /justdial\.com/ },
    { name: 'sulekha', pattern: /sulekha\.com/ },

    // SECONDARY
    { name: 'indiamart', pattern: /indiamart\.com/ },
    { name: 'bing_maps', pattern: /bing\.com\/maps/ },
    { name: 'apple_maps', pattern: /maps\.apple\.com/ },
    { name: 'yelp', pattern: /yelp\.com/ },
    { name: 'yellow_pages', pattern: /yellowpages\.(com|in|co\.uk)/ },

    // SIGNAL-BASED
    { name: 'youtube', pattern: /youtube\.com\/(c\/|channel\/|@).*\/about/ },
    { name: 'instagram', pattern: /instagram\.com\/[^\/]+\/?$/ },
    { name: 'twitter', pattern: /(twitter\.com|x\.com)\/[^\/]+\/?$/ },
    { name: 'facebook', pattern: /facebook\.com\/[^\/]+\/(about|info)/ },

    // INDIRECT B2B
    { name: 'naukri', pattern: /naukri\.com/ },
    { name: 'indeed', pattern: /indeed\.(com|co\.in)/ },
    { name: 'apna', pattern: /apna\.co/ }
];

const detectPlatform = () => {
    const url = window.location.href;
    for (const p of PLATFORMS) {
        if (p.pattern.test(url)) return p.name;
    }
    return null;
};

const init = () => {
    const platform = detectPlatform();
    if (!platform) {
        console.log('[LeadEngine] No supported platform detected on this page');
        return;
    }

    console.log(`[LeadEngine] Detected platform: ${platform}`);

    // Request permission to extract
    chrome.runtime.sendMessage({ type: 'CHECK_EXTRACTION_PERMISSION', platform }, (response) => {
        if (chrome.runtime.lastError) {
            console.warn('[LeadEngine] Communication error:', chrome.runtime.lastError);
            return;
        }

        if (response && response.allowed) {
            loadExtractor(platform);
        } else {
            console.warn(`[LeadEngine] Extraction locked: ${response ? response.reason : 'unknown'}`);
            showLockedBanner(response ? response.reason : 'UPGRADE_REQUIRED');
        }
    });
};

const loadExtractor = (platform) => {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(`content/extractors/${platform}.js`);
    script.type = 'module';
    script.onerror = () => console.error(`[LeadEngine] Failed to load extractor for ${platform}`);
    (document.head || document.documentElement).appendChild(script);
    console.log(`[LeadEngine] Extractor loaded for ${platform}`);
};

const showLockedBanner = (reason) => {
    const banner = document.createElement('div');
    banner.id = 'lead-engine-locked-banner';
    banner.innerHTML = `
        <div style="position:fixed;top:10px;right:10px;background:#1e293b;color:white;padding:12px 20px;border-radius:8px;z-index:999999;font-family:Inter,system-ui,sans-serif;font-size:13px;box-shadow:0 4px 20px rgba(0,0,0,0.3);">
            <strong>LeadEngine</strong>: ${reason === 'LIMIT_REACHED' ? 'Lead limit reached! Upgrade your plan.' : 'This platform requires a paid plan.'}
        </div>
    `;
    document.body.appendChild(banner);
    setTimeout(() => banner.remove(), 8000);
};

// Wait for document to be ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
