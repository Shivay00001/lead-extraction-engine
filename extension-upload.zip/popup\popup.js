import { getAllLeads } from '../common/db.js';

/**
 * Lead Extraction Engine - Popup Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
    updateUI();

    // Activate License
    document.getElementById('activate-btn').addEventListener('click', async () => {
        const key = document.getElementById('license-key').value.trim();
        const msgEl = document.getElementById('license-msg');

        if (!key) return;

        chrome.runtime.sendMessage({ type: 'VALIDATE_LICENSE', key }, (response) => {
            if (response.success) {
                msgEl.innerText = `Activated: ${response.plan}`;
                msgEl.className = 'msg success';
                updateUI();
            } else {
                msgEl.innerText = response.message;
                msgEl.className = 'msg error';
            }
        });
    });

    // Start Scraping
    document.getElementById('start-btn').addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: () => {
                    window.postMessage({ type: 'START_AUTO_SCRAPE' }, '*');
                }
            });
        });
    });

    // Export CSV
    document.getElementById('export-csv').addEventListener('click', async () => {
        const leads = await getAllLeads();
        if (leads.length === 0) return alert('No leads to export');

        // Simple CSV generation
        const headers = ['Name', 'Category', 'Phone', 'Website', 'Address', 'Platform'];
        const csvRows = [headers.join(',')];

        for (const l of leads) {
            const values = [
                `"${l.name}"`,
                `"${l.category}"`,
                `"${l.phone}"`,
                `"${l.website}"`,
                `"${l.address}"`,
                `"${l.platform}"`
            ];
            csvRows.push(values.join(','));
        }

        const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `leads_export_${Date.now()}.csv`;
        a.click();
    });

    // Export JSON
    document.getElementById('export-json').addEventListener('click', async () => {
        const leads = await getAllLeads();
        if (leads.length === 0) return alert('No leads to export');

        const blob = new Blob([JSON.stringify(leads, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `leads_export_${Date.now()}.json`;
        a.click();
    });
});

async function updateUI() {
    chrome.runtime.sendMessage({ type: 'GET_PLAN_INFO' }, (info) => {
        if (!info) return;

        document.getElementById('usage-count').innerText = info.usage;
        document.getElementById('limit-total').innerText = info.limit;

        const badge = document.getElementById('plan-badge');
        badge.innerText = info.planName;
        badge.className = `badge ${info.planId.toLowerCase()}`;

        const progress = (info.usage / info.limit) * 100;
        document.getElementById('progress-fill').style.width = `${Math.min(100, progress)}%`;
    });
}
